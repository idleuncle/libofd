#ifndef __RESOURCE_resources_H__
#define __RESOURCE_resources_H__

#include <gio/gio.h>

extern GResource *resources_get_resource (void);
#endif
