#define HELPER_CONSOLE
#include "gspawn-win32-helper.c"
