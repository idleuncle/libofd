#include "config.h"

#include <offsets.h>

_GI_TEST_EXTERN
void offsets_dummy(void);

/* To avoid an empty compilation unit */
void offsets_dummy(void) {
}
