#ifndef __HEADERONLY_H__
#define __HEADERONLY_H__

typedef enum {
  HEADERONLY_FOO,
  HEADERONLY_BAR,
} HeaderonlyExampleEnum;

#endif
