/* -*- mode: C; c-file-style: "gnu"; indent-tabs-mode: nil; -*- */
#include "config.h"

#include "gtkfrob.h"

void
gtk_frob_language_manager_get_default (void)
{
}
