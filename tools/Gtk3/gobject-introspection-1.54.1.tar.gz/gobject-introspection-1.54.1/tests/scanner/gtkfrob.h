#ifndef __GTKFROB_H__
#define __GTKFROB_H__

#include <glib-object.h>

#include "gitestmacros.h"

/* A global function */

_GI_TEST_EXTERN
void gtk_frob_language_manager_get_default (void);

#endif /* __GTKFROB_H__ */
