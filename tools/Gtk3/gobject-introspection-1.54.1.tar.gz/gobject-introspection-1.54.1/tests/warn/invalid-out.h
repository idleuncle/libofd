/**
 * test_invalid_out:
 * @out: (out invalid):
 */

void test_invalid_out(int *out);

// EXPECT:3: Warning: Test: invalid "out" annotation option: "invalid"
