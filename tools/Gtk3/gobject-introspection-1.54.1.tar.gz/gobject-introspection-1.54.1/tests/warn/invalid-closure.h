
/**
 * test_invalid_closure:
 * @param: (closure a b):
 */
void test_invalid_closure(int param);

// EXPECT:4: Warning: Test: "closure" annotation takes at most one option, 2 given
