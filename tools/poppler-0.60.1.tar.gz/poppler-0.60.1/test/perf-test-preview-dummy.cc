/* Copyright Krzysztof Kowalczyk 2006-2007
   License: GPLv2 */

/* This is a no-op preview support for perf-test.
Using this perf-test still works for performance testing, you just don't
get any visual feedback during testing.
*/

#include "splash/SplashBitmap.h"

void PreviewBitmapInit(void);
void PreviewBitmapDestroy(void);
void PreviewBitmapSplash(SplashBitmap *bmpSplash);

void PreviewBitmapSplash(SplashBitmap *bmpSplash)
{
}

void PreviewBitmapDestroy(void)
{
}

void PreviewBitmapInit(void)
{
}

